from compressible_flow_calc import iteration
from compressible_flow_calc import calc

__CFCVERSION__ = '0.1.3'