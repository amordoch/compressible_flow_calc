from . import cli

cli.CompressibleCLI()
